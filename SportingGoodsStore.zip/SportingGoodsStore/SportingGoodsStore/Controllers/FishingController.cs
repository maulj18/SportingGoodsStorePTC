﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SmartBreadcrumbs.Attributes;

namespace SportingGoodsStore.Controllers
{
    public class FishingController : Controller
    {
        [Breadcrumb("Fishing Index", FromAction = "Index", FromController = typeof(HomeController))]
        public IActionResult Index()
        {
            return View();
        }
        [Breadcrumb("Fishing Equipment", FromAction = "Index", FromController = typeof(HomeController))]
        public IActionResult Equipment()
        {
            return View();
        }
    }
}